(function() {
  var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  jQueryInWindow(function($) {
    var QUICK_PENTEST_URL;
    QUICK_PENTEST_URL = '/wizards/quick_pentest/form/';
    return this.QuickPentestModal = (function(_super) {

      __extends(QuickPentestModal, _super);

      function QuickPentestModal() {
        this.formLoadedSuccessfully = __bind(this.formLoadedSuccessfully, this);

        this.submitFormAjax = __bind(this.submitFormAjax, this);

        this.submitUrl = __bind(this.submitUrl, this);

        this.scanTypeChanged = __bind(this.scanTypeChanged, this);

        this.toggleExcludeIPs = __bind(this.toggleExcludeIPs, this);

        this.toggleGenerateReport = __bind(this.toggleGenerateReport, this);

        this.toggleExploits = __bind(this.toggleExploits, this);

        this.profileButtonPressed = __bind(this.profileButtonPressed, this);

        this.selectProfileButtonAtIndex = __bind(this.selectProfileButtonAtIndex, this);

        this.resetAllProfileButtons = __bind(this.resetAllProfileButtons, this);

        this.getProfileMenu = __bind(this.getProfileMenu, this);
        return QuickPentestModal.__super__.constructor.apply(this, arguments);
      }

      QuickPentestModal.prototype._modelsToTabs = {
        workspace: 0,
        "import": 1,
        scan_task: 1,
        nexpose_task: 1,
        exploit_task: 2,
        report: 3
      };

      QuickPentestModal.prototype.initialize = function() {
        QuickPentestModal.__super__.initialize.apply(this, arguments);
        this.setTitle('Quick PenTest');
        this.setDescription('Set up a test that automatically gathers ' + 'information about the target network, launches attacks ' + 'against the targets, and builds a report of test findings.');
        this.setTabs([
          {
            name: 'Target Settings'
          }, {
            name: 'Configure Scan'
          }, {
            name: 'Run Exploits',
            checkbox: true
          }, {
            name: 'Generate Report',
            checkbox: true
          }
        ]);
        this.setButtons([
          {
            name: 'Cancel',
            "class": 'close'
          }, {
            name: 'Start Scan',
            "class": 'btn primary'
          }
        ]);
        return this.loadForm(QUICK_PENTEST_URL);
      };

      QuickPentestModal.prototype.events = _.extend({
        'click input#tab_run_exploits': 'toggleExploits',
        'click input#tab_generate_report': 'toggleGenerateReport',
        'click a.exclude_toggle': 'toggleExcludeIPs',
        'change input[name="quick_pentest[scan_type]"]': 'scanTypeChanged',
        'click #profile-button-menu li a': 'profileButtonPressed'
      }, TabbedModalView.prototype.events);

      QuickPentestModal.prototype.getProfileMenu = function() {
        return $("#profile-button-menu", this.$modal);
      };

      QuickPentestModal.prototype.resetAllProfileButtons = function() {
        var $menu;
        $menu = this.getProfileMenu();
        return $('span.img, li, a.btn', $menu).removeClass('selected');
      };

      QuickPentestModal.prototype.selectProfileButtonAtIndex = function(idx) {
        var $li, $menu;
        $menu = this.getProfileMenu();
        $li = $('ul>li', $menu).eq(idx);
        return $li.add($('span.img, a.btn', $li)).addClass('selected');
      };

      QuickPentestModal.prototype.profileButtonPressed = function(e) {
        var $li;
        e.preventDefault();
        this.resetAllProfileButtons();
        $li = $(e.currentTarget).parents('li').first();
        return this.selectProfileButtonAtIndex($li.index());
      };

      QuickPentestModal.prototype.toggleExploits = function(e) {
        var checked;
        if (!$(e.currentTarget).parents('li').first().hasClass('selected')) {
          return;
        }
        checked = $(e.currentTarget).is(':checked');
        $('.configure_exploits h3.enabled>span', this.$modal).removeClass('disabled enabled');
        if (checked) {
          $('.configure_exploits h3.enabled>span', this.$modal).text("enabled").addClass('enabled');
          return $("[name='quick_pentest[exploit_enabled]']", this.$modal).attr('value', '1');
        } else {
          $('.configure_exploits h3.enabled>span', this.$modal).text("disabled").addClass('disabled');
          return $("[name='quick_pentest[exploit_enabled]']", this.$modal).removeAttr('value');
        }
      };

      QuickPentestModal.prototype.toggleGenerateReport = function(e) {
        var checked;
        if (!$(e.currentTarget).parents('li').first().hasClass('selected')) {
          return;
        }
        checked = $(e.currentTarget).is(':checked');
        $('.generate_report h3.enabled>span', this.$modal).removeClass('disabled enabled');
        if (checked) {
          $('.generate_report h3.enabled>span', this.$modal).text("enabled").addClass('enabled');
          return $("[name='quick_pentest[report_enabled]']", this.$modal).attr('value', '1');
        } else {
          $('.generate_report h3.enabled>span', this.$modal).text("disabled").addClass('disabled');
          return $("[name='quick_pentest[report_enabled]']", this.$modal).removeAttr('value');
        }
      };

      QuickPentestModal.prototype.toggleExcludeIPs = function(e) {
        e.preventDefault();
        $('.excluded_addresses', this.$modal).show();
        $('.exclude_toggle_wrap', this.$modal).hide();
        return $('.create_project .advanced', this.$modal).css({
          top: '-26px'
        });
      };

      QuickPentestModal.prototype.scanTypeChanged = function(e) {
        var toggle_divs;
        toggle_divs = ['toggle_regular_scan', 'toggle_import'];
        _.each(toggle_divs, function(div) {
          return $("." + div, this.$modal).hide();
        });
        return $(".toggle_" + ($(e.target).val()), this.$modal).show();
      };

      QuickPentestModal.prototype.submitUrl = function() {
        return QUICK_PENTEST_URL;
      };

      QuickPentestModal.prototype.submitFormAjax = function() {
        var $menu, name;
        $menu = this.getProfileMenu();
        name = $('ul>li.selected', $menu).attr('name');
        $('[name="quick_pentest[profile]"]', this.$modal).val(name);
        return QuickPentestModal.__super__.submitFormAjax.apply(this, arguments);
      };

      QuickPentestModal.prototype.formLoadedSuccessfully = function(html) {
        if (!this.content().is(':visible')) {
          return;
        }
        QuickPentestModal.__super__.formLoadedSuccessfully.apply(this, arguments);
        if ($("[name='quick_pentest[report_enabled]']", this.$modal).val() === "true") {
          $("#tab_generate_report", this.$modal).prop('checked', true);
        }
        if ($("[name='quick_pentest[exploit_enabled]']", this.$modal).val() === "true") {
          $("#tab_run_exploits", this.$modal).prop('checked', true);
        }
        $('form.quick_pentest>div.page', this.$el).hide().first().show();
        return this.selectProfileButtonAtIndex(0);
      };

      return QuickPentestModal;

    })(this.TabbedModalView);
  });

}).call(this);
