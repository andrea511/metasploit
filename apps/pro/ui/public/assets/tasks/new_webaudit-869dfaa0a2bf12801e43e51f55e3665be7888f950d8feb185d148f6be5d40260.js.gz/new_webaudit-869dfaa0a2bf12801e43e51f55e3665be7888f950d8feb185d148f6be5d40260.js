(function() {

  jQuery(function($) {
    return $(document).ready(function() {
      return $("#all_targets").checkAll($("#target_list"));
    });
  });

}).call(this);
