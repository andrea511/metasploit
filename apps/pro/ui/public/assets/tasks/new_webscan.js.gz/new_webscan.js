(function() {

  jQuery(function($) {
    return $(document).ready(function() {
      return $("#all_vhosts").checkAll($("#vhost_list"));
    });
  });

}).call(this);
