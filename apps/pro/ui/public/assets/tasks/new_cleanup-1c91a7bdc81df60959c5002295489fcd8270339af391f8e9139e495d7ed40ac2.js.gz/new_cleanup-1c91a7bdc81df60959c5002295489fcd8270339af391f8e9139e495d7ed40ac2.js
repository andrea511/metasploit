(function() {

  jQuery(function($) {
    return $(document).ready(function() {
      return $("#cleanup_all_sessions").checkAll($("#cleanup_sessions"));
    });
  });

}).call(this);
