(function() {

  jQuery(function($) {
    return $(document).ready(function() {
      return $("#all_sessions").checkAll($("#session_list"));
    });
  });

}).call(this);
