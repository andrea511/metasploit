(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["shared/layouts/row_dropdown"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='single-host-view-container'>\n<div class='header'></div>\n<div class='dropdown invisible foundation row'></div>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["shared/layouts/row_dropdown"];
}).call(this);
