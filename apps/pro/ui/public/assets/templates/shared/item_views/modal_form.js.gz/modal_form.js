(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["shared/item_views/modal_form"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='form-content'></div>";
},"useData":true});
  return this.HandlebarsTemplates["shared/item_views/modal_form"];
}).call(this);
