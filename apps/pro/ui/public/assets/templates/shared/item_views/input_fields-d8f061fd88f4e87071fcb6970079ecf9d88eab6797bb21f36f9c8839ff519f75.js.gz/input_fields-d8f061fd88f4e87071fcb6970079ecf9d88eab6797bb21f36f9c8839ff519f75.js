(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["shared/item_views/input_fields"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='dummy'>\nInput Fields will go here\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["shared/item_views/input_fields"];
}).call(this);
