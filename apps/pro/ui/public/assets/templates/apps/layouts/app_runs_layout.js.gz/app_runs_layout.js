(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["apps/layouts/app_runs_layout"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='settings-area'></div>\n<div class='collection-area'></div>";
},"useData":true});
  return this.HandlebarsTemplates["apps/layouts/app_runs_layout"];
}).call(this);
