(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["apps/layouts/apps_overview_collection_layout"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='row'>\n<div class='large-2 columns' style='padding-left: 0;'>\n<div class='filters'></div>\n</div>\n<div class='large-1 columns'>\n&nbsp;\n</div>\n<div class='large-9 columns'>\n<div class='collection row'></div>\n</div>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["apps/layouts/apps_overview_collection_layout"];
}).call(this);
