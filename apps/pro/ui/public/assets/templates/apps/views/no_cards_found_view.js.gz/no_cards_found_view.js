(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["apps/views/no_cards_found_view"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='no-cards-found'>\nNo MetaModules were found that match your search criteria.\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["apps/views/no_cards_found_view"];
}).call(this);
