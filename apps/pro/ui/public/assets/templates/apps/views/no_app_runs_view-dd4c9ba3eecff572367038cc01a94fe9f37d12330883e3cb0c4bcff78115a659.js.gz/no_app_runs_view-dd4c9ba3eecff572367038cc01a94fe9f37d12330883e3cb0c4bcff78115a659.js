(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["apps/views/no_app_runs_view"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='no-app-runs'>\nThere are no MetaModule Runs to display.\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["apps/views/no_app_runs_view"];
}).call(this);
