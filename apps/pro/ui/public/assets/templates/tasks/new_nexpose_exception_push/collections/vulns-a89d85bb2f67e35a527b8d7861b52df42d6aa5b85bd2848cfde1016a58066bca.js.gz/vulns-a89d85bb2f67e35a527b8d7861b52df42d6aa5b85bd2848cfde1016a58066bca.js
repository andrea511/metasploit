(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["tasks/new_nexpose_exception_push/collections/vulns"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='vulns-container row'></div>";
},"useData":true});
  return this.HandlebarsTemplates["tasks/new_nexpose_exception_push/collections/vulns"];
}).call(this);
