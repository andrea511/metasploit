(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["notification_center/item_views/notification_footer/notification_footer_item_view"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='more-text'>\nMore\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["notification_center/item_views/notification_footer/notification_footer_item_view"];
}).call(this);
