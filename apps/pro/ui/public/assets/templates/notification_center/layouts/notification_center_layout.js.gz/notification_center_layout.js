(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["notification_center/layouts/notification_center_layout"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='all-notifications notification-list'>\n<div class='notifications-nav-bar'></div>\n<div class='notifications-container nano'>\n<div class='antiscroll-inner content'>\n<div class='scrollable-container'></div>\n</div>\n</div>\n<div class='notifications-footer'></div>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["notification_center/layouts/notification_center_layout"];
}).call(this);
