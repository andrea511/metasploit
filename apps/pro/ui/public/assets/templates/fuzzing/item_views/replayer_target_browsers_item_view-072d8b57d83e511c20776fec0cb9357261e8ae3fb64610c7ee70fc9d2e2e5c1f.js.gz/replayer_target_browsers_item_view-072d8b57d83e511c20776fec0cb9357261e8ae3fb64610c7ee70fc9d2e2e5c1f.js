(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["fuzzing/item_views/replayer_target_browsers_item_view"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div>\n<h2>Targeted Browsers</h2>\n<div>\nTarget Browser stuff goes here\n</div>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["fuzzing/item_views/replayer_target_browsers_item_view"];
}).call(this);
