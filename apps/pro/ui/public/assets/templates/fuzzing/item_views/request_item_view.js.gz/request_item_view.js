(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["fuzzing/item_views/request_item_view"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='request row'>\n<h2>POST - 2013-04-25 21:48:13 GMT-6</h2>\n<h4>Request Headers</h4>\n<ul>\n<li>Accept: text/javscript</li>\n<li>Accept-Charset: ISO-8859-1, utf-8;q=0.7, 8,q=0.3</li>\n<li>Accept-Enconding:gzip,deflats, sdch</li>\n<li>Accept Languages: en-US, en; q=0.8</li>\n<li>Accept Connection:keep-alive</li>\n</ul>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["fuzzing/item_views/request_item_view"];
}).call(this);
