(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["fuzzing/item_views/fuzzing_attack_header_item_view"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='row'>\n<div class='columns small-2'>Response</div>\n<div class='columns small-6'>\n<button class='small-2'>RENDERED</button>\n<button class='small-2'>OTHER</button>\n<div class='small-8'></div>\n</div>\n<div class='columns small-4'>\n<div class='columns small-8'></div>\n<button class='columns small-4'>Loot!</button>\n</div>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["fuzzing/item_views/fuzzing_attack_header_item_view"];
}).call(this);
