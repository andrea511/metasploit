(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["fuzzing/item_views/request_input_item_view"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<h2>Collect GET</h2>\n<div class='row'>\n<textarea class='small-10 columns field'></textarea>\n<div class='small-2 columns'>\n<button class='columns small-6'>Load</button>\n</div>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["fuzzing/item_views/request_input_item_view"];
}).call(this);
