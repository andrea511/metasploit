(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["fuzzing/item_views/result_page_header_item_view"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<h2 class='row'>Collect POST</h2>";
},"useData":true});
  return this.HandlebarsTemplates["fuzzing/item_views/result_page_header_item_view"];
}).call(this);
