(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["fuzzing/item_views/replayer_parameters_item_view"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div>\n<h2>Parameters</h2>\n<div>Parameter Stuff goes here</div>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["fuzzing/item_views/replayer_parameters_item_view"];
}).call(this);
