(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["fuzzing/layouts/request_collector_layout"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<h1>Request Collector</h1>\n<div class='requests'></div>\n<div class='request-input'></div>";
},"useData":true});
  return this.HandlebarsTemplates["fuzzing/layouts/request_collector_layout"];
}).call(this);
