(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["hosts/layouts/modules"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='modules'></div>";
},"useData":true});
  return this.HandlebarsTemplates["hosts/layouts/modules"];
}).call(this);
