(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["hosts/layouts/host_view_layout"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='container foundation row'>\n<div class='host-stats-overview foundation large-6 columns'></div>\n<div class='tags foundation large-6 columns'></div>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["hosts/layouts/host_view_layout"];
}).call(this);
