(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["hosts/layouts/web_vulnerabilities"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='web-vulns'></div>";
},"useData":true});
  return this.HandlebarsTemplates["hosts/layouts/web_vulnerabilities"];
}).call(this);
