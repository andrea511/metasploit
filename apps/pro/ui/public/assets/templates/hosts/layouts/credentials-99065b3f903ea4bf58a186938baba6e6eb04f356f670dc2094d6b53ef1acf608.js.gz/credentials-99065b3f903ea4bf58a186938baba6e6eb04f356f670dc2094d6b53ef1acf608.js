(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["hosts/layouts/credentials"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='credentials'>\n<h4>Logins</h4>\n<div class='accessing-logins'></div>\n<h4>Captured Credentials</h4>\n<div class='originating-creds'></div>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["hosts/layouts/credentials"];
}).call(this);
