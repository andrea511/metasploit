(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["hosts/layouts/captured_data"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='btnRow'>\n<span class='btn'>\n<a class='new' href='javascript:void(0)'>\nNew Captured Data\n</a>\n</span>\n</div>\n<div id='loot_table'></div>";
},"useData":true});
  return this.HandlebarsTemplates["hosts/layouts/captured_data"];
}).call(this);
