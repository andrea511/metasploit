(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["hosts/layouts/attempts"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='attempts-table'>\n<div class='table'></div>\n<div class='clearfix'></div>\n</div>";
},"useData":true});
  return this.HandlebarsTemplates["hosts/layouts/attempts"];
}).call(this);
