(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["hosts/layouts/file_shares"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='shares'></div>\n<div class='clearfix'></div>";
},"useData":true});
  return this.HandlebarsTemplates["hosts/layouts/file_shares"];
}).call(this);
