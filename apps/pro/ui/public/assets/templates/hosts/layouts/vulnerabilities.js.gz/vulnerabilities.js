(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["hosts/layouts/vulnerabilities"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div class='vulns'></div>\n<div style='clear:both'></div>\n<div class='vuln-modal'></div>";
},"useData":true});
  return this.HandlebarsTemplates["hosts/layouts/vulnerabilities"];
}).call(this);
