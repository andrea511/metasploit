(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["hosts/layouts/notes"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div id='notes_table'></div>";
},"useData":true});
  return this.HandlebarsTemplates["hosts/layouts/notes"];
}).call(this);
