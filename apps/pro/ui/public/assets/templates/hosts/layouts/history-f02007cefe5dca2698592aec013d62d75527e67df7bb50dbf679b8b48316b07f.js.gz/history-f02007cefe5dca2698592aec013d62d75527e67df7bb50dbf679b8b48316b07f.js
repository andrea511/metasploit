(function() {
  this.HandlebarsTemplates || (this.HandlebarsTemplates = {});
  this.HandlebarsTemplates["hosts/layouts/history"] = Handlebars.template({"compiler":[8,">= 4.3.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<div id='history_table'></div>";
},"useData":true});
  return this.HandlebarsTemplates["hosts/layouts/history"];
}).call(this);
