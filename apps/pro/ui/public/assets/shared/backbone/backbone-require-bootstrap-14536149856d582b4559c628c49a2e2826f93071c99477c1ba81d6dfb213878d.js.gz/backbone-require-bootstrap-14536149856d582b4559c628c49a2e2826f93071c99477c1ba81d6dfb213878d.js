(function() {

  define([], function() {
    return Backbone;
  });

}).call(this);
