(function() {

  define(['jquery'], function($) {
    return Backbone.Marionette;
  });

}).call(this);
