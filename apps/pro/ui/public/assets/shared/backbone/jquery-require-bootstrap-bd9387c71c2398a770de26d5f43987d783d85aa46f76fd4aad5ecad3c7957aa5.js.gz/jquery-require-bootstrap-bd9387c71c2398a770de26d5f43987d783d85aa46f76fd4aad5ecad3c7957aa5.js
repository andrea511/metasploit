(function() {

  define([], function() {
    return jQuery;
  });

}).call(this);
