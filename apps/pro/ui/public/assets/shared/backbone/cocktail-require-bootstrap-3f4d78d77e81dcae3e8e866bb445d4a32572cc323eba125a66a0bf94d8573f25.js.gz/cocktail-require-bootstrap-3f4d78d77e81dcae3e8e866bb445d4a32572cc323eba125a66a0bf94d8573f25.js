(function() {

  define([], function() {
    return Cocktail;
  });

}).call(this);
