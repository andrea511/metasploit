(function() {

  define([], function() {
    return _;
  });

}).call(this);
