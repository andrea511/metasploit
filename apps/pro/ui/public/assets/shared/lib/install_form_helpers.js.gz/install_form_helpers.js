(function() {

  define(['/assets/shared/lib/handlebars_form_helpers-545c54f925b85bea61deea449f7a1c9180ca29255be59ad028c6d567a5ca466f.js'], function(FormHelpers) {
    return FormHelpers.register(Handlebars);
  });

}).call(this);
